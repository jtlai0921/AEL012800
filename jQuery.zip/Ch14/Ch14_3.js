$('#description').hover(
 function() {
   $(this).addClass('hover');
 }, function() {
   $(this).removeClass('hover');  
});